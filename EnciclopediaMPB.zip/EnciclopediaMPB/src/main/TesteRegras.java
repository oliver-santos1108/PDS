package main;

import model.Album;
import model.Artista;
import model.Musica;

public class TesteRegras {

	public static void main(String[] args) {
		
		Artista a = new Artista();
		a.setNome("Rita Lee");
		a.setData_nascimento(1947);
		a.setConjuges("Roberto de Carvalho");
		a.setQuant_albuns(30);
		a.setAlbuns("Fruto Proibído");
		a.setData_falecimento(2023);
		a.setIdade(75);
		a.setLocal_nascimento("São Paulo");
		System.out.println("Rita Lee -> " + a.validarArtista());
		
		Album al = new Album();
		al.setNome("Fruto Proibído");
		al.setAno_lancamento(1975);
		al.setArtista("Rita Lee");
		al.setGenero("Rock");
		al.setGravadora("Som Livre");
		System.out.println("Fruto Proibído -> " + al.validarAlbum());
		
		Musica m = new Musica();
		m.setNome("Agora Só Falta Você");
		m.setAlbum("Fruto Proibído");
		m.setArtista("Rita Lee");
		m.setData_lancamento(1975);
		m.setGenero("Rock");
		System.out.println("Agora Só Falta Você -> " + m.validarMusica());
	}

}
