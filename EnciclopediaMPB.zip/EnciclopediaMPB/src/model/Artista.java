package model;

public class Artista {
	private String nome;
	private int data_nascimento;
	private String conjuges;
	private int quant_albuns;
	private String albuns;
	private int data_falecimento;
	private int idade;
	private String local_nascimento;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getData_nascimento() {
		return data_nascimento;
	}
	public void setData_nascimento(int data_nascimento) {
		this.data_nascimento = data_nascimento;
	}
	public String getConjuges() {
		return conjuges;
	}
	public void setConjuges(String conjuges) {
		this.conjuges = conjuges;
	}
	public int getQuant_albuns() {
		return quant_albuns;
	}
	public void setQuant_albuns(int quant_albuns) {
		this.quant_albuns = quant_albuns;
	}
	public String getAlbuns() {
		return albuns;
	}
	public void setAlbuns(String albuns) {
		this.albuns = albuns;
	}
	public int getData_falecimento() {
		return data_falecimento;
	}
	public void setData_falecimento(int data_falecimento) {
		this.data_falecimento = data_falecimento;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public String getLocal_nascimento() {
		return local_nascimento;
	}
	public void setLocal_nascimento(String local_nascimento) {
		this.local_nascimento = local_nascimento;
	}
	
	public String validarArtista() {
		 if (nome == null || nome.trim().isEmpty()) {
		 return "Preencha o nome do artista.";
		 }
		 if ( data_nascimento <= 0) {
		 return "Preencha a data de nascimento do artista.";
		 }
		 if (quant_albuns <= 0) {
		 return "Preencha a quantidade de álbuns corretamente.";
		 }
		 if (albuns == null || albuns.trim().isEmpty()) {
			 return "Preencha o nome dos álbuns.";
		 }
		 if (idade < 0) {
		 return "Preencha a idade corretamente.";
		 }
		 if (local_nascimento == null || local_nascimento.trim().isEmpty()) {
		 return "Preencha o local de nascimento.";
		 }
		 return null;
		 }
}
