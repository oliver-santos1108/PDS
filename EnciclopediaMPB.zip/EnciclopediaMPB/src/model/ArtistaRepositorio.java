package model;

import java.util.ArrayList;
import java.util.List;

//Passo 5 pendente - preciso pensar nas regras
public class ArtistaRepositorio {
	
	private List<Artista> artistas = new ArrayList<>();
	public void salvar(Artista a) {
		String problema = a.validarArtista();
		if (problema != null) {
			throw new IllegalArgumentException(problema);
		}
		
		artistas.add(a);

	}
	
	public List<Musica> musicas = new ArrayList<>();
	public List<Album> albuns = new ArrayList<>();
	
	

	
}
