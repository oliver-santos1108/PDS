package model;

public class Album {

	private String nome;
	private int ano_lancamento;
	private String genero;
	private String artista;
	private String gravadora;
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getAno_lancamento() {
		return ano_lancamento;
	}
	public void setAno_lancamento(int ano_lancamento) {
		this.ano_lancamento = ano_lancamento;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	public String getArtista() {
		return artista;
	}
	public void setArtista(String artista) {
		this.artista = artista;
	}
	public String getGravadora() {
		return gravadora;
	}
	public void setGravadora(String gravadora) {
		this.gravadora = gravadora;
	}
	
	public String validarAlbum() {
		 if (nome == null || nome.trim().isEmpty()) {
		 return "Preencha o nome do álbum.";
		 }
		 if ( ano_lancamento <= 0) {
		 return "Preencha a data de nascimento do artista.";
		 }
		 if (artista == null || artista.trim().isEmpty()) {
			 return "Preencha o nome do álbum.";
		 }
		 if (gravadora == null || gravadora.trim().isEmpty()) {
			 return "Preencha o nome do álbum.";
		 }
		 return null;
		 }

}
