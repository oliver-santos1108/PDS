package model;

public class Musica {
	
	private String nome;
	private int data_lancamento;
	private String genero;
	private String artista;
	private String album;

	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getData_lancamento() {
		return data_lancamento;
	}
	public void setData_lancamento(int data_lancamento) {
		this.data_lancamento = data_lancamento;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	public String getArtista() {
		return artista;
	}
	public void setArtista(String artista) {
		this.artista = artista;
	}
	public String getAlbum() {
		return album;
	}
	public void setAlbum(String album) {
		this.album = album;
	}
	public String validarMusica() {
		 if (nome == null || nome.trim().isEmpty()) {
		 return "Preencha o nome do álbum.";
		 }
		 if ( data_lancamento <= 0) {
		 return "Preencha a data de nascimento do artista.";
		 }
		 if (genero == null || genero.trim().isEmpty()) {
			 return "Preencha o nome do álbum.";
		 }
		 if (artista == null || artista.trim().isEmpty()) {
			 return "Preencha o nome do álbum.";
		 }
		 if (album == null || album.trim().isEmpty()) {
			 return "Preencha o nome do álbum.";
		 }
		 return null;
		 }
}
